create
    definer = root@localhost procedure SetCounter(INOUT counter int, IN inc int)
BEGIN

    SET counter = counter + inc;

END;

